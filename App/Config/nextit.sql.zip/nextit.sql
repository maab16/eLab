--
-- Database: `nextit`
--

-- --------------------------------------------------------

--
-- Table structure for table `availability`
--

CREATE TABLE `availability` (
  `id` int(11) NOT NULL,
  `availability_id` int(1) NOT NULL,
  `availability_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `availability`
--

INSERT INTO `availability` (`id`, `availability_id`, `availability_name`) VALUES
(1, 0, 'Out of Stock'),
(2, 1, 'In Stock'),
(3, 2, 'Up Coming'),
(5, 3, 'COMING SOON');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(11) NOT NULL,
  `brand_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_name`) VALUES
(1, 'HP'),
(2, 'DELL'),
(3, 'Lenovo');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `ip_address` varchar(255) NOT NULL,
  `qty` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `product_id`, `ip_address`, `qty`) VALUES
(1, 28, '27.54.148.205', 1),
(2, 27, '27.54.148.205', 1),
(3, 26, '27.54.148.205', 3);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(11) NOT NULL,
  `cat_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_name`) VALUES
(1, 'laptop'),
(2, 'desktop'),
(3, 'motherboard');

-- --------------------------------------------------------

--
-- Table structure for table `desktops`
--

CREATE TABLE `desktops` (
  `id` int(11) NOT NULL,
  `product_code` varchar(255) NOT NULL,
  `processor` varchar(255) NOT NULL,
  `chipset` varchar(255) NOT NULL,
  `ram` varchar(255) NOT NULL,
  `hard_disk` varchar(255) NOT NULL,
  `display` varchar(255) NOT NULL,
  `graphics` varchar(255) NOT NULL,
  `audio` varchar(255) NOT NULL,
  `optical_disk_drive` varchar(255) NOT NULL,
  `mouse` varchar(255) NOT NULL,
  `keyboard` varchar(255) NOT NULL,
  `operating_system` varchar(255) NOT NULL,
  `warranty` varchar(255) NOT NULL,
  `others` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `desktops`
--

INSERT INTO `desktops` (`id`, `product_code`, `processor`, `chipset`, `ram`, `hard_disk`, `display`, `graphics`, `audio`, `optical_disk_drive`, `mouse`, `keyboard`, `operating_system`, `warranty`, `others`) VALUES
(1, '3020MT Core i3 OS ', 'Intel 4th Gen Core i3-4150 Processor/3.50 GHz', 'Intel® H81 Chipset', '4GB RAM-1600MHz', '500 GB SATA-7200rpm', 'Dell 18.5" Monitor E1914H', 'HD 4400 Graphics', 'Internal Dell Business Audio Speaker', '16X Half Height DVD+/-RW Drive', 'Dell MS111 USB Optical Mouse', 'Dell KB212-B QuietKey USB Keyboard Black', 'Free DOS', '3 years Warranty', '');

-- --------------------------------------------------------

--
-- Table structure for table `desktop_description`
--

CREATE TABLE `desktop_description` (
  `id` int(11) NOT NULL,
  `product_code` varchar(255) NOT NULL,
  `processor` varchar(255) NOT NULL,
  `chipset` varchar(255) NOT NULL,
  `ram` varchar(255) NOT NULL,
  `hard_disk` varchar(255) NOT NULL,
  `display` varchar(255) NOT NULL,
  `graphics` varchar(255) NOT NULL,
  `audio` varchar(255) NOT NULL,
  `optical_disk_drive` varchar(255) NOT NULL,
  `mouse` varchar(255) NOT NULL,
  `keyboard` varchar(255) NOT NULL,
  `operating_system` varchar(255) NOT NULL,
  `warranty` varchar(255) NOT NULL,
  `others` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `desktop_description`
--

INSERT INTO `desktop_description` (`id`, `product_code`, `processor`, `chipset`, `ram`, `hard_disk`, `display`, `graphics`, `audio`, `optical_disk_drive`, `mouse`, `keyboard`, `operating_system`, `warranty`, `others`) VALUES
(9, 'Dell Optiplex 3020MT Core i3-4160 Processor with free DOS', 'Intel 4th Gen Core i3-4160 Processor/3.60 GHz', 'Intel&reg; H81 Chipset', '4GB RAM-1600MHz', '500 GB SATA-7200rpm', 'Dell 18.5&quot; Monitor E1914H', 'HD 4400 Graphics/Free DOS', 'Internal Dell Business Audio Speaker', '16X Half Height DVD+/-RW Drive', 'Dell MS111 USB Optical Mouse', 'Dell KB212-B QuietKey USB Keyboard Black', 'Free Dos', '3 years Warranty', ''),
(10, '3020MT Core i3 OS', 'Intel 4th Gen Core i3-4150 Processor/3.50 GHz', 'Intel&reg; H81 Chipset', '4GB RAM-1600MHz', '500 GB SATA-7200rpm', 'Dell 18.5&quot; Monitor E1914H', 'HD 4400 Graphics', 'Internal Dell Business Audio Speaker', '16X Half Height DVD+/-RW Drive', 'Dell MS111 USB Optical Mouse', 'Dell KB212-B QuietKey USB Keyboard Black', 'Free DOS', '3 years Warranty', ''),
(11, '3020MT Core i3 ', 'Intel 4th Gen Core i3-4160 Processor/3.60 GHz', 'Intel&reg; H81 Chipset', '4GB RAM-1600MHz', '500 GB SATA-7200rpm', 'Dell 18.5&quot; Monitor E1914H', 'HD 4400 Graphics/Free DOS', 'Internal Dell Business Audio Speaker', '16X Half Height DVD+/-RW Drive', 'Dell MS111 USB Optical Mouse', 'Dell KB212-B QuietKey USB Keyboard Black', ' WINDOWS 7 Professional 64 bit &amp; WINDOWS 8.1 Professional', '3 years Warranty', ''),
(12, '3020MT Core i5 ', 'Intel 4th Gen Core i5-4590 Processor/3.30 GHz Max Turbo up to 3.7GHz', 'Intel&reg; H81 Chipset', '4GB RAM-1600MHz', '500 GB SATA-7200rpm', 'Dell 18.5&quot; Monitor E1914H', 'HD 4600 Graphics', 'Internal Dell Business Audio Speaker', '16X Half Height DVD+/-RW Drive', 'Dell MS111 USB Optical Mouse', 'Dell KB212-B QuietKey USB Keyboard Black', 'Free Dos', '3 years Warranty', ''),
(13, '3020MT Core i5 OS ', 'Intel 4th Gen Core i5-4590 Processor/3.30 GHz Max Turbo up to 3.7GHz', 'Intel&reg; H81 Chipset', '4GB RAM-1600MHz', '500 GB SATA-7200rpm', 'Dell 18.5&quot; Monitor E1914H', 'HD 4600 Graphics', 'Internal Dell Business Audio Speaker', '16X Half Height DVD+/-RW Drive', 'Dell MS111 USB Optical Mouse', 'Dell KB212-B QuietKey USB Keyboard Black', 'Factory Preloaded Genuine Microsoft windows 8.1 professional 64bit downgrade able to windows 7 professional 64bit license with Windows 8.1 pro or windows 7 pro Recovery CD media', '3 years Warranty', ''),
(14, '7020MT Core i5 ', 'Intel 4th Gen Core i5-4590 Processor/3.30 GHz Max Turbo up to 3.7GHz', 'Intel&reg; Q87 Chipset', '4GB RAM-1600MHz', '500 GB SATA-7200rpm', 'Dell 18.5&quot; Monitor E1914H', 'HD 4600 Graphics', 'Internal Dell Business Audio Speaker', '16X Half Height DVD+/-RW Drive', 'Dell MS111 USB Optical Mouse', 'Dell KB212-B QuietKey USB Keyboard Black', 'Free Dos', '3 years Warranty', ''),
(15, '7020MT Core i7 1TB HDD ', 'Intel 4th Gen Core i7-4790 Processor/3.60 GHz Max Turbo up to 4.00GHz', 'Intel&reg; Q87 Chipset', '4GB RAM-1600MHz', '500 GB SATA-7200rpm', 'Dell 18.5&quot; Monitor E1914H', 'HD 4600 Graphics', 'Internal Dell Business Audio Speaker', '16X Half Height DVD+/-RW Drive', 'Dell MS111 USB Optical Mouse', 'Dell KB212-B QuietKey USB Keyboard Black', 'Free Dos', '3Yrs SADMG', ''),
(16, '7020MT Core i7 ', 'Intel 4th Gen Core i7-4790 Processor/3.60 GHz Max Turbo up to 4.00GHz', 'Intel&reg; Q87 Chipset', '4GB RAM-1600MHz', '500 GB SATA-7200rpm', 'Dell 18.5&quot; Monitor E1914H', 'HD 4400 Graphics/Free DOS', 'Internal Dell Business Audio Speaker', '16X Half Height DVD+/-RW Drive', 'Dell MS111 USB Optical Mouse', 'Dell KB212-B QuietKey USB Keyboard Black', 'Free Dos', '3Yrs SADMG', ''),
(17, '7020MT Core i7 OS ', 'Intel 4th Gen Core i7-4790 Processor/3.60 GHz Max Turbo up to 4.00GHz', 'Intel&reg; Q87 Chipset', '4GB RAM-1600MHz', '500 GB SATA-7200rpm', 'Dell 18.5&quot; Monitor E1914H', 'HD 4600 Graphics', 'Internal Dell Business Audio Speaker', '16X Half Height DVD+/-RW Drive', 'Dell MS111 USB Optical Mouse', 'Dell KB212-B QuietKey USB Keyboard Black', 'Factory Preloaded Genuine Microsoft windows 8.1 professional 64bit downgrade able to windows 7 professional 64bit license with Windows 8.1 pro or windows 7 pro Recovery CD media', '3Yrs SADMG', '');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` int(11) NOT NULL,
  `group_name` varchar(255) NOT NULL,
  `permission` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `group_name`, `permission`) VALUES
(1, 'Standard User', ''),
(2, 'Administrator', '{"admin":1}'),
(3, 'Moderator', '{"moderator":1}');

-- --------------------------------------------------------

--
-- Table structure for table `laptops`
--

CREATE TABLE `laptops` (
  `id` int(11) NOT NULL,
  `Model` varchar(255) NOT NULL,
  `Part No` varchar(255) NOT NULL,
  `CPU Technology` varchar(255) NOT NULL,
  `Operating System` varchar(255) NOT NULL,
  `Chipset` varchar(255) NOT NULL,
  `System Memory` varchar(255) NOT NULL,
  `Display` varchar(255) NOT NULL,
  `Graphics` varchar(255) NOT NULL,
  `Hard Disk` varchar(255) NOT NULL,
  `Keyboard` varchar(255) NOT NULL,
  `Pointing Device` text NOT NULL,
  `Communications` text NOT NULL,
  `Built-in Camera` text NOT NULL,
  `Sound System` text NOT NULL,
  `Interfaces` text NOT NULL,
  `Battery Type` varchar(255) NOT NULL,
  `AC Adapter` varchar(255) NOT NULL,
  `Security and Protection` varchar(255) NOT NULL,
  `Physical Dimensions` varchar(255) NOT NULL,
  `Weight` varchar(255) NOT NULL,
  `Color Variation` varchar(255) NOT NULL,
  `Warranty` varchar(255) NOT NULL,
  `others` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `laptop_description`
--

CREATE TABLE `laptop_description` (
  `id` int(11) NOT NULL,
  `product_code` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `processor` varchar(255) NOT NULL,
  `chipset` varchar(255) NOT NULL,
  `ram` varchar(255) NOT NULL,
  `hard_disk` varchar(255) NOT NULL,
  `display` varchar(255) NOT NULL,
  `graphics` varchar(255) NOT NULL,
  `camera` varchar(255) NOT NULL,
  `audio` varchar(255) NOT NULL,
  `optical_disk_drive` varchar(255) NOT NULL,
  `keyboard` varchar(255) NOT NULL,
  `lan_wifi` varchar(255) NOT NULL,
  `battery` varchar(255) NOT NULL,
  `carry_case` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `weight` varchar(255) NOT NULL,
  `operating_system` varchar(255) NOT NULL,
  `warranty` varchar(255) NOT NULL,
  `others` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `laptop_description`
--

INSERT INTO `laptop_description` (`id`, `product_code`, `model`, `processor`, `chipset`, `ram`, `hard_disk`, `display`, `graphics`, `camera`, `audio`, `optical_disk_drive`, `keyboard`, `lan_wifi`, `battery`, `carry_case`, `color`, `weight`, `operating_system`, `warranty`, `others`) VALUES
(1, 'Lenovo Yoga', 'Lenovo Yoga Black 12.5&quot; Laptop', 'Intel&reg; Core&trade; i7-6500U GPU Processor 3.1 GHz', 'Intel SoC (System on Chip) platform', '8GB DDR4 2133 MHz SoDIMM', '512 GB Solid State Drive 2.5&quot; SATA 3', '12.5&quot; FHD (1920 x 1080) IPS, 300 NT', 'Intel HD Graphics 520 in processor', 'HD720p resolution, fi xed focus', 'HD Audio, Conexant&reg; CX11852 codec, Dolby&reg; Advanced Audio&trade; /', '', '', '', 'TP BT 6 Cell Lithium (47 wh)', '', 'Matt Black', '', 'Genuine Windows&reg; 10 Pro (English)', '3-year Standard Limited Warranty', ''),
(2, 'DELL INSPIRON 15-5559 ', 'DELL INSPIRON 15-5559', 'INTEL CORE-i5-6th Gen 6200U up to 2.8 GHz', 'Intel', '8GB', '1TB', '15.6''''', 'AMD Radeon(TM) R5 M335 2GB DDR3', 'Integrated Widescreen HD (720p) Webcam with Digital Microphone', 'High Definition Audio with Waves MaxxAudio&reg; Pro 1 combo headphone / microphone jack', 'DVD', '', '10/100 Ethernet LAN, Dell(TM) Wireless 1704 802.11b/g/n with Bluetooth v4.0', '4-Cell', 'Dell original carry case', 'BLK GLOSS, SLV MATTE', '', 'Free DOS', '2 years Warranty', ''),
(3, 'DELL INSPIRON 15-7568', 'DELL INSPIRON 15-7568 ', 'INTEL CORE-i7-6th Gen 6500U 2.50 - 3.10 GHz', 'Intel', '8GB', '1TB', '15.6''''', 'HD GR 520', 'Integrated Widescreen HD (720p) Webcam with Digital Microphone', 'High Definition Audio with Waves MaxxAudio&reg; Pro 1 combo headphone / microphone jack', 'No', '', '10/100 Ethernet LAN, Dell(TM) Wireless 1704 802.11b/g/n with Bluetooth v4.0', '3-Cell', 'Dell original carry case', 'Black', '', 'Free DOS', '2 years Warranty', ''),
(4, 'DELL XPS 9350', 'DELL XPS 9350', 'INTEL CORE-i7-6th Gen 6560U up to 3.20 GHz', 'Intel', '8GB', '256 SSD', '13.3'''' QHD TOUCH', 'HD GR 520', 'Integrated Widescreen HD (720p) Webcam with Digital Microphone', 'High Definition Audio with Waves MaxxAudio&reg; Pro 1 combo headphone / microphone jack', 'No', '', '10/100 Ethernet LAN, Dell(TM) Wireless 1704 802.11b/g/n with Bluetooth v4.0', '56WHr Integreted', 'Dell original carry case', 'Silver', '', 'WINDOWS 10 HOME 64 BIT (SINGLE LANGUAGE)', '2 years Warranty', '');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_code` varchar(255) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `model` varchar(255) NOT NULL,
  `tag` varchar(255) NOT NULL,
  `price` double NOT NULL,
  `product_image` text NOT NULL,
  `rating` float NOT NULL,
  `available` tinyint(1) NOT NULL DEFAULT '0',
  `entry` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_code`, `product_name`, `brand`, `category`, `model`, `tag`, `price`, `product_image`, `rating`, `available`, `entry`, `modified`) VALUES
(20, 'Dell Optiplex 3020MT Core i3-4160 Processor with free DOS', 'Dell Optiplex 3020MT Core i3-4160 Processor/3.60 GHz with free DOS', 'DELL', 'desktop', '', 'dell Optiplex 3020MT Core i3-4160 Processor/3.60 GHz with free DOS', 38500, 'dell desktop 3.jpg', 0, 1, '2016-06-10 06:33:34', '2016-06-10 06:33:34'),
(21, '3020MT Core i3 OS', 'Dell Optiplex 3020MT Core i3 With Free DOS', 'DELL', 'desktop', '', 'Dell Optiplex 3020MT Core i3 With Free DOS', 35500, 'dell desktop 9.jpg', 0, 1, '2016-06-10 06:31:14', '2016-06-10 06:31:14'),
(22, '3020MT Core i3 OS ', 'Dell Optiplex 3020MT Core i3 With OS', 'DELL', 'desktop', '', 'Dell Optiplex 3020MT Core i3 OS', 46870, 'dell desktop 2.jpg', 0, 1, '2016-06-10 01:40:59', '2016-06-10 01:40:59'),
(23, '3020MT Core i3 ', 'Dell Optiplex 3020MT Core i3-4160 With free DOS', 'DELL', 'desktop', '', 'Dell Optiplex 3020MT Core i3', 48000, 'dell desktop 5.jpg', 0, 1, '2016-06-10 06:31:40', '2016-06-10 06:31:40'),
(24, '3020MT Core i5 ', 'Dell Optiplex 3020MT Core i5 With Free DOS', 'DELL', 'desktop', '', 'Dell Optiplex 3020MT Core i5', 45780, 'dell desktop 4.jpg', 0, 1, '2016-06-10 06:29:26', '2016-06-10 06:29:26'),
(25, '3020MT Core i5 OS ', 'Dell Optiplex 3020MT Core i5 with OS', 'DELL', 'desktop', '', ' Dell Optiplex 3020MT Core i5 OS', 56680, 'dell desktop 5.jpg', 0, 1, '2016-06-10 06:30:21', '2016-06-10 06:30:21'),
(26, '7020MT Core i5 ', 'Dell Optiplex 7020MT Core i5 with free DOS', 'DELL', 'desktop', '', 'Dell Optiplex 7020MT Core i5', 49050, 'dell desktop 9.jpg', 0, 1, '2016-06-10 06:30:40', '2016-06-10 06:30:40'),
(27, '7020MT Core i7 1TB HDD ', 'Dell Optiplex 7020MT Core i7 1TB HDD', 'DELL', 'desktop', '', 'Dell Optiplex 7020MT Core i7 1TB HDD', 61040, 'dell desktop 2.jpg', 0, 1, '2016-06-10 06:28:35', '2016-06-10 06:28:35'),
(28, '7020MT Core i7 ', 'Dell Optiplex 7020MT Core i7 with free DOS', 'DELL', 'desktop', '', 'Dell Optiplex 7020MT Core i7', 59450, 'dell desktop 8.jpg', 0, 1, '2016-06-10 06:29:39', '2016-06-10 06:29:39'),
(31, '7020MT Core i7 OS ', 'Dell Optiplex 7020MT Core i7 with OS', 'DELL', 'desktop', '', 'Dell Optiplex 7020MT Core i7 OS', 70850, 'dell desktop 6.jpg', 0, 3, '2016-06-10 06:32:09', '2016-06-10 06:32:09'),
(33, 'Lenovo Yoga', 'Lenovo Yoga Intel&reg; Core&trade; i7-6500U GPU Processor 2.6GHz', 'Lenovo', 'laptop', '', 'Lenovo Yoga Intel&reg; Core&trade; i7-6500U GPU Processor 2.6GHz', 134500, 'laptop1.jpg', 0, 1, '2016-06-18 11:51:48', '2016-06-18 11:51:48'),
(34, 'Lenovo Yoga', 'Lenovo Yoga Intel&reg; Core&trade; i5-6200U GPU Processor 2.4GHz', 'Lenovo', 'laptop', '', 'Lenovo Yoga Intel&reg; Core&trade; i5-6200U GPU Processor 2.4GHz', 134500, 'laptop2.jpg', 0, 1, '2016-06-19 12:09:40', '2016-06-19 12:09:40'),
(35, 'DELL INSPIRON 15-5559 ', 'DELL INSPIRON 15-5559 INTEL CORE-i5-6th Gen 6200U up to 2.8 GHz', 'DELL', 'laptop', '', 'DELL INSPIRON 15-5559 INTEL CORE-i5-6th Gen 6200U up to 2.8 GHz', 0, 'laptop3.jpg', 0, 3, '2016-06-19 12:14:27', '2016-06-19 12:14:27'),
(36, 'DELL INSPIRON 15-7568', 'DELL INSPIRON 15-7568 INTEL CORE-i7-6th Gen 6500U 2.50 - 3.10 GHz', 'Lenovo', 'laptop', '', 'DELL INSPIRON 15-7568 INTEL CORE-i7-6th Gen 6500U 2.50 - 3.10 GHz', 0, 'laptop4.jpg', 0, 3, '2016-06-19 12:17:38', '2016-06-19 12:17:38'),
(37, 'DELL XPS 9350', 'DELL XPS 9350 INTEL CORE-i7-6th Gen 6560U up to 3.20 GHz', 'Lenovo', 'laptop', '', 'DELL XPS 9350 INTEL CORE-i7-6th Gen 6560U up to 3.20 GHz', 0, 'laptop5.jpg', 0, 2, '2016-06-19 12:20:46', '2016-06-19 12:20:46');

-- --------------------------------------------------------

--
-- Table structure for table `sidebar_menus`
--

CREATE TABLE `sidebar_menus` (
  `id` int(11) NOT NULL,
  `menu` varchar(255) NOT NULL,
  `parent` int(10) NOT NULL,
  `child_parent` int(10) NOT NULL,
  `child` int(10) NOT NULL,
  `sub_id` int(10) NOT NULL,
  `link` varchar(255) DEFAULT '#'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sidebar_menus`
--

INSERT INTO `sidebar_menus` (`id`, `menu`, `parent`, `child_parent`, `child`, `sub_id`, `link`) VALUES
(1, 'Laptop / Notebook', 0, 0, 0, 0, '#'),
(2, 'PC Components', 0, 0, 0, 0, '#'),
(3, 'Desktop PC', 0, 0, 0, 0, '#'),
(4, 'Tablet', 0, 0, 0, 0, '#'),
(5, 'Smart Phone', 0, 0, 0, 0, '#'),
(6, 'Accessories', 0, 0, 0, 0, '#'),
(7, 'Printing solution', 0, 0, 0, 0, '#'),
(8, 'Projector', 0, 0, 0, 0, '#'),
(9, 'Software Solution', 0, 0, 0, 0, '#'),
(10, 'DELL Laptop', 1, 1, 0, 0, '#'),
(11, 'HP Laptop', 1, 1, 0, 0, '#'),
(12, 'Apple Laptop', 1, 1, 0, 0, '#'),
(13, 'Apple Desktop', 3, 1, 0, 0, '#'),
(14, 'HP Desktop', 3, 1, 0, 0, '#'),
(19, 'Envy', 1, 0, 11, 2, '/products/laptop/hp/envy/'),
(20, 'Pavilion', 1, 0, 11, 2, '/products/laptop/hp/pavilion/'),
(21, 'Primo', 1, 0, 10, 2, '/products/laptop/dell/primo/');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `slider_id` int(11) NOT NULL,
  `slider_image` text NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`slider_id`, `slider_image`, `link`) VALUES
(9, 'slider7.jpg', '/products/desktop/'),
(10, 'slider6.jpg', '/products/desktop/'),
(11, 'slider5.jpg', '/products/desktop/'),
(12, 'slider3.jpg', '/products/desktop/'),
(13, 'slider4.jpg', '/products/desktop/');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `birth_date` varchar(255) NOT NULL,
  `religion` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `user_image` text NOT NULL,
  `countryCode` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `zip_code` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `comphany` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '0',
  `grp` tinyint(1) NOT NULL DEFAULT '1',
  `joined` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `fname`, `lname`, `email`, `gender`, `birth_date`, `religion`, `password`, `salt`, `user_image`, `countryCode`, `city`, `zip_code`, `address`, `comphany`, `fax`, `phone`, `active`, `grp`, `joined`) VALUES
(14, 'abuahsan', 'MD Abu ahsan', 'Apu', 'odeskbg@gmail.com', 'male', '', 'islam', '3098a32ef3922b8267da3c644415848b3a99bb09b04b63673d7ea3f0b711fc1d', '?푛9?C????qP4??B`e?څZ??s', 'abuahsan.jpg', 'BD', 'Narayanganj', '1400', '1/1 Shere Bangla road', '', '', '010824844042', 1, 2, '2016-06-08 00:00:00'),
(15, 'basir', 'মো: অাবু আহসান', 'Basir', 'abuahsan77@gmail.com', '', '', '', '178c0fa4bfa0ffdfb3aefe64f89d2ddd3ff2fae44be8ae402ee3155c35b6be5f', 't?̛???7???Qz???=(6?,x?\Z????7', '', '', '', '', '', '', '', '010824844042', 1, 1, '2016-06-09 00:00:00'),
(16, 'abuahsan91', 'MD. Abu Ahsan', 'Basir', 'abuahsan08@gmail.com', '', '', '', '3098a32ef3922b8267da3c644415848b3a99bb09b04b63673d7ea3f0b711fc1d', '????>?o?Q ?7?	???@???Z;???', '', '', '', '', '', '', '', '010824844042', 0, 1, '2016-06-10 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users_info`
--

CREATE TABLE `users_info` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `countryCode` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `region` varchar(255) NOT NULL,
  `regionName` varchar(255) NOT NULL,
  `timezone` varchar(255) NOT NULL,
  `isp` varchar(255) NOT NULL,
  `org` varchar(255) NOT NULL,
  `as_name` varchar(255) NOT NULL,
  `lat` float NOT NULL,
  `lon` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_info`
--

INSERT INTO `users_info` (`id`, `ip_address`, `country`, `countryCode`, `city`, `zip`, `region`, `regionName`, `timezone`, `isp`, `org`, `as_name`, `lat`, `lon`) VALUES
(20, '103.43.151.233', 'BD', 'BD', 'Narayanganj', '1412', 'Dhaka', '', '', '', 'AS133854 X-press Technologies Limited.', '', 23.6135, 90.503),
(21, '27.54.148.23', 'BD', 'BD', '', '', '', '', '', '', 'AS133854 X-press Technologies Limited.', '', 23.7, 90.375),
(22, '27.54.148.205', 'Bangladesh', 'BD', 'Narayanganj', '1400', 'C', 'Dhaka Division', 'Asia/Dhaka', 'X-Press Technology', 'X-press Technologies Limited.', 'AS133854 X-press Technologies Limited.', 23.7197, 90.5634);

-- --------------------------------------------------------

--
-- Table structure for table `users_session`
--

CREATE TABLE `users_session` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `hash` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_session`
--

INSERT INTO `users_session` (`id`, `user_id`, `hash`) VALUES
(2, 14, '0dcf4f146b66b841efd5725e648c09dbe990ea639fffdda82c7ea26e6e760e3f');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `availability`
--
ALTER TABLE `availability`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `desktops`
--
ALTER TABLE `desktops`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `desktop_description`
--
ALTER TABLE `desktop_description`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `laptops`
--
ALTER TABLE `laptops`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `laptop_description`
--
ALTER TABLE `laptop_description`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `sidebar_menus`
--
ALTER TABLE `sidebar_menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`slider_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `users_info`
--
ALTER TABLE `users_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_session`
--
ALTER TABLE `users_session`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `availability`
--
ALTER TABLE `availability`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `desktops`
--
ALTER TABLE `desktops`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `desktop_description`
--
ALTER TABLE `desktop_description`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `laptops`
--
ALTER TABLE `laptops`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `laptop_description`
--
ALTER TABLE `laptop_description`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `sidebar_menus`
--
ALTER TABLE `sidebar_menus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `slider_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `users_info`
--
ALTER TABLE `users_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `users_session`
--
ALTER TABLE `users_session`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
